self.__uv$config = {
  prefix: "/a/",
  bare: "/fq/",
  encodeUrl: Ultraviolet.codec.xor.encode,
  decodeUrl: Ultraviolet.codec.xor.decode,
  handler: "/assets/ultra/handler.js?v=9-30-2024",
  bundle: "/assets/ultra/bundle.js?v=9-30-2024",
  config: "/assets/ultra/config.js?v=9-30-2024",
  sw: "/assets/ultra/sw.js?v=9-30-2024",
};
